sap.ui.define([
    'mickey/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("mickey.controller.Second",{
        
    });
});